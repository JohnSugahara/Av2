public class Guerreiro extends Personagem{

    Arma arma = new Arma();

    public Guerreiro(String nome, int vida, int energia, int poder) {
        super(nome,vida,energia, poder);
    }

    public Arma arma(){
        this.arma.nome = "Machado de Guerra";
        this.arma.dano = 15;

        return arma;
    }


    public void atacar(Personagem personagem[])
    {
        System.out.println("O Guerreiro gira perfurando o inimigo com o seu machado.");
        personagem[0].vida -= (int) (this.arma.dano * 2.5); // Machadada
    }



}
