public class Main {
    public static void main(String[] args) {

        Personagem personagem[] = new Personagem[3];

        Assassino p1 = new Assassino("Wut", 75, 80, 80);
        Guerreiro p2 = new Guerreiro("Stark", 125, 100, 40);
        Mago p3 = new Mago("Fern", 35, 250, 200);

        personagem[0] = p1;
        personagem[1] = p2;
        personagem[2] = p3;

        Assassino assassin = new Assassino(p1.nome, p1.vida, p1.energia, p1.poder);
        Mago mage = new Mago(p3.nome, p3.vida, p3.energia, p3.poder);
        Guerreiro warrior = new Guerreiro(p2.nome, p2.vida, p2.energia, p2.poder);

        p1.usarHabilidade();
        p2.usarHabilidade();
        p3.usarHabilidade();
        p1.atacar(personagem);
        p2.atacar(personagem);






    }
}