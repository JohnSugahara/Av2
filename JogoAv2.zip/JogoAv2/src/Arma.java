public class Arma {

    String nome;
    int dano;

}
