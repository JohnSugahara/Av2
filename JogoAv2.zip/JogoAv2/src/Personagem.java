public class Personagem {

    protected String nome;
    protected int vida;
    protected int energia;
    protected int poder;

    public Personagem(String nome, int vida, int energia, int poder){
        this.nome = nome;
        this.vida = vida;
        this.energia = energia;
        this.poder = poder;
    }


    public void usarHabilidade(){

    }

}
