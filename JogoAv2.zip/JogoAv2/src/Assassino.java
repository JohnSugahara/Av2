public class Assassino extends Personagem{

    Arma arma = new Arma();

    public Assassino(String nome, int vida, int energia, int poder) {
        super(nome,vida,energia,poder);
    }

    public Arma arma(){
        this.arma.nome = "Espada Curta";
        this.arma.dano = 6;

        return arma;
    }

    public void atacar(Personagem personagem[])
    {
        System.out.println("O Assassino perfura o inimigo duas vezes com a sua adaga");
        personagem[0].vida -= (int) (this.arma.dano * 2.5); // Perfurada
    }
}
